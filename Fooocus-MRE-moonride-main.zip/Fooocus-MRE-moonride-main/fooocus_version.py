version = '2.0.78.5 MRE'
full_version = 'Fooocus ' + version
